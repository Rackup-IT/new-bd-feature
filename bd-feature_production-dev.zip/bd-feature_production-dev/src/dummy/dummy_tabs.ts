import { TabSection } from "../features/admin-panel/types/type";

export const DUMMY_TABS: TabSection[] = [
  {
    id: "01",
    edition: "Global",
    href: "#",
    title: "Section 01",
  },
];
